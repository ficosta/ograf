# Sport Lineup

Team roster grid with numbered player cards and staggered reveal. Tutorial from ograf.dev.

- **Package id:** `dev.ograf.tutorial.sport-lineup`
- **Version:** 1.0.0
- **License:** MIT

## What's inside

| File | Purpose |
| --- | --- |
| `sport-lineup.ograf.json` | Manifest -- what a renderer reads. |
| `graphic.mjs` | Web Component with the full OGraf lifecycle. |
| `style.css` | Stylesheet, loaded via a `<link>` injected by graphic.mjs. |
| `thumbnail.webp` | 1920×1080 preview, declared in the manifest's `thumbnails`. |
| `LICENSE` | MIT licence for the package. |
| `fonts/` | Local font files (if present), with the font's license alongside. |
| `README.md` | This file. |

## Deploy to a compliant OGraf renderer

Point any OGraf-compliant system at the manifest:

- **ograf-server** -- reference renderer, self-host. <https://github.com/SuperFlyTV/ograf-server>
- **SPX-GC** -- professional OGraf controller. <https://github.com/TuomoKu/SPX-GC>
- **CasparCG** -- open-source playout server. <https://github.com/CasparCG/server>

## License

MIT. Built as part of the [ograf.dev](https://ograf.dev) tutorials.
