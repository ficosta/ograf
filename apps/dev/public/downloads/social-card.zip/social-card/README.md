# Social Media Card

Social post overlay that slides in from the right with an auto-generated avatar from the user's initials. Tutorial from ograf.dev.

- **Package id:** `dev.ograf.tutorial.social-card`
- **Version:** 1.0.0
- **License:** MIT

## What's inside

| File | Purpose |
| --- | --- |
| `social-card.ograf.json` | Manifest -- what a renderer reads. |
| `graphic.mjs` | Web Component with the full OGraf lifecycle. |
| `style.css` | Stylesheet, loaded via a `<link>` injected by graphic.mjs. |
| `fonts/` | Local font files (if present), with the font's license alongside. |
| `README.md` | This file. |

## Deploy to a compliant OGraf renderer

Point any OGraf-compliant system at the manifest:

- **ograf-server** -- reference renderer, self-host. <https://github.com/SuperFlyTV/ograf-server>
- **SPX-GC** -- professional OGraf controller. <https://github.com/TuomoKu/SPX-GC>
- **CasparCG** -- open-source playout server. <https://github.com/CasparCG/server>

## License

MIT. Built as part of the [ograf.dev](https://ograf.dev) tutorials.
