# Election Bars

Animated horizontal bar chart for election results with data-driven widths and color-coded parties. Tutorial from ograf.dev.

- **Package id:** `dev.ograf.tutorial.election-bars`
- **Version:** 1.0.0
- **License:** MIT

## What's inside

| File | Purpose |
| --- | --- |
| `election-bars.ograf.json` | Manifest -- what a renderer reads. |
| `graphic.mjs` | Web Component with the full OGraf lifecycle. |
| `style.css` | Stylesheet, loaded via a `<link>` injected by graphic.mjs. |
| `fonts/` | Local font files (if present), with the font's license alongside. |
| `README.md` | This file. |

## Deploy to a compliant OGraf renderer

Point any OGraf-compliant system at the manifest:

- **ograf-server** -- reference renderer, self-host. <https://github.com/SuperFlyTV/ograf-server>
- **SPX-GC** -- professional OGraf controller. <https://github.com/TuomoKu/SPX-GC>
- **CasparCG** -- open-source playout server. <https://github.com/CasparCG/server>

## License

MIT. Built as part of the [ograf.dev](https://ograf.dev) tutorials.
